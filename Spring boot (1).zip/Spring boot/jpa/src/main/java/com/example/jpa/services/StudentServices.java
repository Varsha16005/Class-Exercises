package com.example.jpa.services;

import org.springframework.stereotype.Service;

import com.example.jpa.model.StudentDetails;
import com.example.jpa.repository.StudentRepository;

@Service
public class StudentServices {

    private StudentRepository studentRepository;

    public StudentServices(StudentRepository studentRepository)
    {
        this.studentRepository = studentRepository;
    }
    public StudentDetails saveStudentDetails(StudentDetails studentDetails)
    {
        return studentRepository.save(studentDetails);
    }
}
