package com.example.cw12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cw12Application {

	public static void main(String[] args) {
		SpringApplication.run(Cw12Application.class, args);
	}

}
