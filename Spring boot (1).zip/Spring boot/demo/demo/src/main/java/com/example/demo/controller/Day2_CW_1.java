package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.config.AppConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class Day2_CW_1 {
    @Autowired
    public AppConfig configObject;
    @GetMapping("/app")
    public String getMethodName() {
        return "AppName: "+configObject.appName+" AppVersion: "+configObject.appVersion;
    }
    
}
