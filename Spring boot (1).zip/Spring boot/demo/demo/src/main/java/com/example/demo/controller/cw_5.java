package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentModel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class cw_5 {
    @GetMapping("/allstudents")
    public List<StudentModel> getMethodName() {
        List<StudentModel> studentList = new ArrayList<StudentModel>();
        StudentModel p = new StudentModel(101, "Ezhil");
        studentList.add(p);
        StudentModel q = new StudentModel(102, "senthil");
        studentList.add(q);
        return studentList;
    }
    
}
