package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class Application_Prop {
    @Value("${my.gmail}")
    public String mail;
    @GetMapping("/mail")
    public String getMethodName() {
        return mail;
    }
    
}
