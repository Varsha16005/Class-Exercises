package com.example.day6cw3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6cw3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
