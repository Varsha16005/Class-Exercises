package com.example.day1cy1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1cy1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1cy1Application.class, args);
	}

}
