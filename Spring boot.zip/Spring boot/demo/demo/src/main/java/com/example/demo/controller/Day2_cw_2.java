package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentDay2;

import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class Day2_cw_2 {
    @GetMapping("/students")
    public StudentDay2 getMethodName() {
        StudentDay2 obj = new StudentDay2("Nithish", 22);
        return obj;
    }
    
}
