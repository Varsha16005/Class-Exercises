package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



@RestController
public class cw_2 {
    @GetMapping("/students/{name}")
    public String getMethodName(@PathVariable("name") String studentName) {
        return "welcome"+" "+studentName;
    }
    
}
